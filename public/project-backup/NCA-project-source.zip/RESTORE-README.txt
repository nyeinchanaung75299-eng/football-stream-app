Source snapshot: ed7a9078df34f08476f8e8a40ebe8aec84183128
Verify files using BACKUP-INVENTORY.json.
Restore Git repository, install pinned dependencies, provision the backend and apply migrations in filename order to a NEW empty database. Never replay historical migrations on production.
Signing keys, provider tokens, GitHub/Supabase/Cloudflare secrets and database DATA are not in this archive. Store those separately in an encrypted recovery vault. Do not generate a new signing key when updating an installed app.
APK files: use private Admin bot /apk_admin and /apk_viewer.
