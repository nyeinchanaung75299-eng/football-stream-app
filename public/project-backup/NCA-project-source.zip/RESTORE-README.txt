Source snapshot: 87c24144f14ce80306eb374ea53735db275b6233
Verify files using BACKUP-INVENTORY.json.
Restore Git repository, install pinned dependencies, provision the backend and apply migrations in filename order to a NEW empty database. Never replay historical migrations on production.
Signing keys, provider tokens, GitHub/Supabase/Cloudflare secrets and database DATA are not in this archive. Store those separately in an encrypted recovery vault. Do not generate a new signing key when updating an installed app.
APK files: use private Admin bot /apk_admin and /apk_viewer.
