import 'dart:async';

import 'package:flutter/material.dart';
import 'package:supabase_flutter/supabase_flutter.dart';
import '../analytics_service.dart';
import '../football_english.dart';
import '../services/manual_source_url.dart';
import '../source_line_validation.dart';
import '../services/match_paging.dart';
import '../widgets/unsaved_changes_guard.dart';
import '../services/function_gateway.dart';
import '../services/channel_source_service.dart';
import '../services/match_line_label.dart';
import '../widgets/match_stream_card.dart';
import 'channel_source_picker_page.dart';

class LiveLinksPage extends StatefulWidget {
  const LiveLinksPage({
    super.key,
    this.initialMatchId,
    this.initialStreamUrl,
    this.initialReferer,
    this.initialOrigin,
    this.initialChannel,
  });

  final String? initialMatchId;
  final String? initialStreamUrl;
  final String? initialReferer;
  final String? initialOrigin;
  final ChannelStreamSelection? initialChannel;

  @override
  State<LiveLinksPage> createState() => _LiveLinksPageState();
}

class _LiveLinksPageState extends State<LiveLinksPage> {
  final _formExit = FormExitHandle();
  final _drafts = <String, Map<String, String>>{};
  Map<String, String> get _draft => {
        'name': serverName.text,
        'url': link.text,
        'referer': referer.text,
        'origin': origin.text,
        'kid': keyId.text,
        'key': keyData.text,
        'web': webViewUrl.text,
        'type': streamType,
        'webMode': useWebView.toString()
      };
  bool get _hasDraft =>
      link.text.trim().isNotEmpty ||
      webViewUrl.text.trim().isNotEmpty ||
      referer.text.trim().isNotEmpty ||
      origin.text.trim().isNotEmpty ||
      keyId.text.trim().isNotEmpty ||
      keyData.text.trim().isNotEmpty ||
      serverName.text != 'Server 1';
  void _restoreDraft(Map<String, String> value) {
    serverName.text = value['name'] ?? 'Server 1';
    link.text = value['url'] ?? '';
    referer.text = value['referer'] ?? '';
    origin.text = value['origin'] ?? '';
    keyId.text = value['kid'] ?? '';
    keyData.text = value['key'] ?? '';
    webViewUrl.text = value['web'] ?? '';
    streamType = value['type'] ?? 'auto';
    useWebView = value['webMode'] == 'true';
    selectedChannel = null;
    selectedChannelName = null;
  }

  String? selectedChannelName;
  ChannelStreamSelection? selectedChannel;
  final serverName = TextEditingController(text: 'Server 1');
  final link = TextEditingController();
  final referer = TextEditingController();
  final origin = TextEditingController();
  final keyId = TextEditingController();
  final keyData = TextEditingController();
  final webViewUrl = TextEditingController();

  String streamType = 'auto';
  String? matchId;
  bool useWebView = false;
  bool loading = false;
  final Set<String> checkingLinks = <String>{};
  final Set<String> updatingLinks = <String>{};
  bool testingHealth = false;
  late Future<List<Map<String, dynamic>>> _matchesFuture;
  Future<List<Map<String, dynamic>>>? _linksFuture;
  Future<List<Map<String, dynamic>>>? _epgFuture;

  final streamTypes = const <String, String>{
    'auto': 'Auto / Direct',
    'hls': 'HLS (.m3u8)',
    'dash': 'DASH (.mpd)',
    'flv': 'FLV (.flv)',
    'mp4': 'MP4 / Progressive',
  };

  @override
  void initState() {
    super.initState();
    matchId = widget.initialMatchId;
    if (widget.initialStreamUrl != null) {
      link.text = widget.initialStreamUrl!;
      streamType = detectStreamType(link.text);
    }
    referer.text = widget.initialReferer ?? '';
    origin.text = widget.initialOrigin ?? '';
    if (widget.initialChannel != null) fillFromChannel(widget.initialChannel!);
    _matchesFuture = _startMatchesLoad();
    if (matchId != null) {
      _linksFuture = _startLinksLoad();
      _epgFuture = _syncEpg(matchId!);
    }
  }

  void fillFromChannel(ChannelStreamSelection selected) {
    selectedChannel = selected;
    selectedChannelName = selected.displayLabel;
    serverName.text = selected.displayLabel;
    link.text = selected.streamUrl;
    referer.text = selected.referer;
    origin.text = selected.origin;
    keyId.text = selected.keyId;
    keyData.text = selected.keyData;
    streamType =
        detectStreamType(selected.streamUrl, fallback: selected.streamType);
    useWebView = false;
    webViewUrl.clear();
  }

  Future<void> chooseChannel() async {
    if (loading) return;
    final selected = await Navigator.of(context).push<ChannelStreamSelection>(
      MaterialPageRoute(builder: (_) => const ChannelSourcePickerPage()),
    );
    if (selected != null && mounted) setState(() => fillFromChannel(selected));
  }

  @override
  void dispose() {
    for (final controller in [
      serverName,
      link,
      referer,
      origin,
      keyId,
      keyData,
      webViewUrl
    ]) {
      controller.dispose();
    }
    _formExit.dispose();
    super.dispose();
  }

  void reloadMatches() {
    if (!mounted) return;
    setState(() {
      _matchesFuture = _startMatchesLoad();
    });
  }

  void reloadLinks() {
    if (!mounted || matchId == null) return;
    setState(() {
      _linksFuture = _startLinksLoad();
    });
  }

  void selectMatch(String? value) {
    setState(() {
      final unassigned = matchId == null && _hasDraft ? _draft : null;
      final channel = matchId == null ? selectedChannel : null;
      if (matchId != null) _drafts[matchId!] = _draft;
      matchId = value;
      _restoreDraft(value == null ? {} : (_drafts[value] ?? unassigned ?? {}));
      if (channel != null && value != null) {
        selectedChannel = channel;
        selectedChannelName = channel.displayLabel;
      }
      _linksFuture = value == null ? null : _startLinksLoad();
      _epgFuture = value == null ? null : _syncEpg(value);
    });
  }

  Future<List<Map<String, dynamic>>> _startMatchesLoad() {
    final request = loadMatches();
    request.ignore();
    return request;
  }

  // Verify football teams and kickoff against saved NCA EPG on opening match.
  // Only server-approved direct keyless lines may be attached to the match.
  Future<List<Map<String, dynamic>>> _syncEpg(String id) async {
    // Invalid or unfinished match selections are not queried by the EPG sync.
    final validMatchId = RegExp(
      r'^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$',
      caseSensitive: false,
    ).hasMatch(id);
    if (!validMatchId) return <Map<String, dynamic>>[];

    var addedLines = 0;
    try {
      final sync = await Supabase.instance.client.functions.invoke(
          'auto-match-channels',
          body: {'match_id': id}).timeout(const Duration(seconds: 30));
      if (sync.data is Map) {
        addedLines = ((sync.data as Map)['addedLines'] as num?)?.toInt() ?? 0;
      }
    } catch (_) {
      // Display last verified EPG channel metadata if the relay is down.
    }
    try {
      final result = await Supabase.instance.client
          .from('nca_epg_auto_match_channels')
          .select('channel_id,programme_title,programme_start,channels(name)')
          .eq('match_id', id)
          .order('programme_start')
          .timeout(const Duration(seconds: 12));
      final guide = List<Map<String, dynamic>>.from(result);
      try {
        final linkedRows = await Supabase.instance.client
            .from('stream_links')
            .select('channel_id,channel_line_id')
            .eq('match_id', id)
            .timeout(const Duration(seconds: 12));
        final linkedIds = List<Map<String, dynamic>>.from(linkedRows)
            .where((row) => row['channel_line_id'] != null)
            .map((row) => row['channel_id']?.toString())
            .toSet();
        for (final row in guide) {
          row['auto_attached'] =
              linkedIds.contains(row['channel_id']?.toString());
        }
      } catch (_) {
        // The verified EPG data can still be displayed without link status.
      }
      // Don't reset an existing server query unless auto-matching added lines.
      if (mounted && matchId == id && addedLines > 0) {
        setState(() => _linksFuture = _startLinksLoad());
      }
      return guide;
    } catch (_) {
      return <Map<String, dynamic>>[];
    }
  }

  Widget _autoGuideCard(ColorScheme colors) {
    // Do not render auto-EPG UI for an incomplete / non-database match ID.
    // This also keeps legacy manual editor and its recovery UI unchanged.
    if (matchId == null ||
        !RegExp(
          r'^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$',
          caseSensitive: false,
        ).hasMatch(matchId!)) return const SizedBox.shrink();
    return Card(
      child: Padding(
        padding: const EdgeInsets.all(14),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            const Text('📺 AUTOMATIC TV SCHEDULE MATCH',
                style: TextStyle(fontWeight: FontWeight.w900)),
            const SizedBox(height: 8),
            FutureBuilder<List<Map<String, dynamic>>>(
              key: ValueKey('auto-epg-$matchId'),
              future: _epgFuture ??= _syncEpg(matchId!),
              builder: (context, snapshot) {
                if (!snapshot.hasData) {
                  return const LinearProgressIndicator();
                }
                final mapped = snapshot.data!;
                if (mapped.isEmpty) {
                  return const Text('No verified TV schedule match yet.');
                }
                return Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text('${mapped.length} TV channel(s) matched by EPG'),
                    for (final row in mapped)
                      ListTile(
                        dense: true,
                        contentPadding: EdgeInsets.zero,
                        leading: const Icon(Icons.tv),
                        title: Text(row['channels'] is Map
                            ? ((row['channels'] as Map)['name']?.toString() ??
                                'TV Channel')
                            : 'TV Channel'),
                        subtitle: Text(row['auto_attached'] == true
                            ? 'Direct channel line auto-saved to match'
                            : 'EPG verified • direct line not attached'),
                      ),
                    Text(
                        'Protected channels are listed for reference. '
                        'DRM keys and session URLs are not copied.',
                        style: TextStyle(
                            color: colors.onSurfaceVariant, fontSize: 12)),
                  ],
                );
              },
            ),
          ],
        ),
      ),
    );
  }

  Future<List<Map<String, dynamic>>> _startLinksLoad() {
    final request = loadLinks();
    // A preset starts this in parallel with the matches query. Handle errors
    // immediately even before its nested FutureBuilder can mount.
    request.ignore();
    return request;
  }

  String? nullable(String value) {
    final v = value.trim();
    return v.isEmpty ? null : v;
  }

  String detectStreamType(String value, {String fallback = 'auto'}) {
    final v = value.trim().toLowerCase();
    if (v.contains('.m3u8')) return 'hls';
    if (v.contains('.mpd')) return 'dash';
    if (v.contains('.flv')) return 'flv';
    if (v.contains('.mp4')) return 'mp4';
    return fallback;
  }

  void message(String text) {
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(content: Text(text)),
    );
  }

  Widget _dashCompatibilityNotice(BuildContext context) {
    final colors = Theme.of(context).colorScheme;
    return Row(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Icon(Icons.info_outline_rounded, size: 18, color: colors.primary),
        const SizedBox(width: 8),
        Expanded(
          child: Text(
            'DASH/MPD and saved ClearKey settings work with compatible players. '
            'Keep an HLS backup for devices that cannot play this source. '
            'Health checks report reachability only.',
            style: TextStyle(
              color: colors.onSurfaceVariant,
              fontSize: 12,
              height: 1.4,
            ),
          ),
        ),
      ],
    );
  }

  Future<List<Map<String, dynamic>>> loadMatches() async {
    final data = await loadAdminMatches(Supabase.instance.client,
        columns:
            'id,home_team,away_team,home_logo_url,away_logo_url,league,kickoff_at,sort_order,is_live,is_active,is_finished,is_featured,publish_state,deleted_at',
        activeOnly: true,
        publishedOnly: true);

    return List<Map<String, dynamic>>.from(data).where((row) {
      // Live matches are Admin-controlled. Do not hide them from the
      // stream editor just because kickoff passed or an automated status
      // says finished; Admin must still be able to edit/delete the match
      // and its individual stream lines.
      return row['deleted_at'] == null &&
          row['is_active'] == true &&
          row['is_featured'] != false &&
          (row['publish_state'] ?? 'published') == 'published';
    }).toList();
  }

  Future<List<Map<String, dynamic>>> loadLinks() async {
    if (matchId == null) return [];
    final data = await Supabase.instance.client
        .from('stream_links')
        .select()
        .eq('match_id', matchId!)
        .order('sort_order')
        .order('created_at')
        .timeout(const Duration(seconds: 10));
    return List<Map<String, dynamic>>.from(data);
  }

  String? _validateInput(
      String value, String type, String ref, String org, String kid, String key,
      {bool web = false}) {
    final uri = Uri.tryParse(value.trim());
    if (web) {
      if (uri == null ||
          !const {'http', 'https'}.contains(uri.scheme) ||
          uri.host.isEmpty ||
          uri.userInfo.isNotEmpty) return 'Enter a valid HTTP(S) player URL.';
    } else if (!isValidManualStreamUrl(value, streamType: type))
      return 'Enter a direct video URL, not a website page.';
    for (final header in [ref, org]) {
      if (header.trim().isEmpty) continue;
      final parsed = Uri.tryParse(header.trim());
      if (parsed == null ||
          !const {'http', 'https'}.contains(parsed.scheme) ||
          parsed.host.isEmpty ||
          parsed.userInfo.isNotEmpty ||
          header.contains('\n') ||
          header.contains('\r'))
        return 'Referer and Origin must be valid HTTP(S) URLs.';
    }
    return web
        ? null
        : manualClearKeyError(streamType: type, keyId: kid, keyData: key);
  }

  Future<void> addLink() async {
    if (loading) return;
    if (matchId == null) {
      message('Select a match first.');
      return;
    }

    if (!useWebView && link.text.trim().isEmpty) {
      message('Paste a stream URL.');
      return;
    }

    if (useWebView && webViewUrl.text.trim().isEmpty) {
      message('Paste a WebView URL.');
      return;
    }

    final effectiveInput =
        useWebView ? webViewUrl.text.trim() : link.text.trim();
    final type = detectStreamType(link.text, fallback: streamType);
    final inputError = _validateInput(effectiveInput, type, referer.text,
        origin.text, keyId.text, keyData.text,
        web: useWebView);
    if (inputError != null) {
      message(inputError);
      return;
    }
    final savedMatchId = matchId!;
    final sentDraft = _draft;
    setState(() => loading = true);

    try {
      final name =
          serverName.text.trim().isEmpty ? 'Server' : serverName.text.trim();

      final effectiveType = useWebView
          ? 'auto'
          : detectStreamType(link.text, fallback: streamType);

      await Supabase.instance.client.from('stream_links').insert({
        'match_id': savedMatchId,
        if (!useWebView && selectedChannel?.channelLineId != null)
          'channel_id': selectedChannel!.channelId,
        if (!useWebView && selectedChannel?.channelLineId != null)
          'channel_line_id': selectedChannel!.channelLineId,
        'label': name,
        'resolution': name,
        'stream_type': effectiveType,
        'stream_url': useWebView ? '' : link.text.trim(),
        'referer': nullable(referer.text),
        'origin': nullable(origin.text),
        'key_id': !useWebView && effectiveType == 'dash'
            ? nullable(keyId.text)
            : null,
        'key_data': !useWebView && effectiveType == 'dash'
            ? nullable(keyData.text)
            : null,
        'use_webview': useWebView,
        'webview_url': useWebView ? webViewUrl.text.trim() : null,
        'send_notification': false,
        'is_active': true,
      }).timeout(const Duration(seconds: 12));

      unawaited(AnalyticsService.capture(
        'stream added',
        properties: {
          'match_id': savedMatchId,
          'stream_type': effectiveType,
          'use_webview': useWebView,
          'has_referer': referer.text.trim().isNotEmpty,
          'has_origin': origin.text.trim().isNotEmpty,
          'has_clearkey':
              keyId.text.trim().isNotEmpty && keyData.text.trim().isNotEmpty,
        },
      ));

      if (!mounted) return;

      if (matchId == savedMatchId &&
          _draft.entries.every((e) => sentDraft[e.key] == e.value)) {
        _restoreDraft({});
        _drafts.remove(savedMatchId);
        message('Server added.');
        reloadLinks();
      } else {
        _drafts.remove(savedMatchId);
        if (matchId == savedMatchId)
          message('Server added. Your newer draft was kept.');
      }
    } on TimeoutException {
      if (mounted) {
        message('Could not confirm the save. Refresh before trying again.');
        reloadLinks();
      }
    } catch (e) {
      unawaited(AnalyticsService.capture(
        'stream add failed',
        properties: {
          'match_selected': matchId != null,
          'use_webview': useWebView,
        },
      ));
      if (!mounted) return;
      message(e.toString());
    } finally {
      if (mounted) setState(() => loading = false);
    }
  }

  Future<void> testHealth() async {
    if (matchId == null) {
      message('Select a match first.');
      return;
    }

    setState(() => testingHealth = true);
    try {
      final data = await FunctionGateway.invoke(
        'stream-health',
        body: {'match_id': matchId},
      );
      unawaited(AnalyticsService.capture(
        'stream health checked',
        properties: {
          'scope': 'match',
          if (data is Map && data['health_status'] != null)
            'health_status': data['health_status'].toString(),
        },
      ));
      if (!mounted) return;

      if (data is Map && data['summary'] is Map) {
        final summary = Map<String, dynamic>.from(data['summary'] as Map);
        message(
          'Health: ${summary['healthy'] ?? 0} healthy, '
          '${summary['slow'] ?? 0} slow, '
          '${summary['failed'] ?? 0} failed.',
        );
      } else {
        message('Health check finished.');
      }

      reloadLinks();
    } catch (e) {
      unawaited(AnalyticsService.capture(
        'stream health check failed',
        properties: {'scope': 'match'},
      ));
      if (mounted) message('Health check failed: $e');
    } finally {
      if (mounted) setState(() => testingHealth = false);
    }
  }

  Future<void> deleteLink(String id) async {
    final ok = await showDialog<bool>(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text('Delete server?'),
        content: const Text(
          'Only this link/server will be deleted. The match will stay.',
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context, false),
            child: const Text('Cancel'),
          ),
          FilledButton(
            onPressed: () => Navigator.pop(context, true),
            child: const Text('Delete'),
          ),
        ],
      ),
    );

    if (ok != true) return;

    try {
      await Supabase.instance.client
          .from('stream_links')
          .delete()
          .eq('id', id)
          .select('id')
          .single()
          .timeout(const Duration(seconds: 12));

      unawaited(AnalyticsService.capture(
        'stream deleted',
        properties: {'match_selected': matchId != null},
      ));

      if (mounted) {
        message('Server deleted.');
        reloadLinks();
      }
    } catch (e) {
      unawaited(AnalyticsService.capture('stream delete failed'));
      if (mounted) message('Delete failed: $e');
    }
  }

  Future<void> setActive(String id, bool value) async {
    if (updatingLinks.contains(id)) return;
    setState(() => updatingLinks.add(id));
    try {
      await Supabase.instance.client
          .from('stream_links')
          .update({'is_active': value})
          .eq('id', id)
          .select('id')
          .single()
          .timeout(const Duration(seconds: 12));
      unawaited(AnalyticsService.capture('stream active changed',
          properties: {'is_active': value}));

      reloadLinks();
    } on TimeoutException {
      if (mounted) {
        message('Could not confirm the change. Refresh to check the server.');
        reloadLinks();
      }
    } catch (_) {
      if (mounted) message('Could not update the server. Please retry.');
    } finally {
      if (mounted) setState(() => updatingLinks.remove(id));
    }
  }

  Future<void> checkHealth(String id) async {
    if (checkingLinks.contains(id)) return;

    setState(() => checkingLinks.add(id));
    try {
      final data = await FunctionGateway.invoke(
        'stream-health',
        body: {'link_id': id},
      );

      unawaited(AnalyticsService.capture(
        'stream health checked',
        properties: {
          'scope': 'link',
          if (data is Map && data['health_status'] != null)
            'health_status': data['health_status'].toString(),
        },
      ));

      if (mounted) {
        reloadLinks();
        if (data is Map) {
          final status = data['health_status'] ?? 'unknown';
          final latency = data['latency_ms'];
          message(
            latency == null
                ? 'Health: $status'
                : 'Health: $status • ${latency}ms',
          );
        }
      }
    } catch (e) {
      unawaited(AnalyticsService.capture(
        'stream health check failed',
        properties: {'scope': 'link'},
      ));
      if (mounted) message('Health check failed: $e');
    } finally {
      if (mounted) {
        setState(() => checkingLinks.remove(id));
      }
    }
  }

  Future<void> editLink(Map<String, dynamic> row) async {
    final name = TextEditingController(
      text: conciseMatchLineLabel(
          '${row['label'] ?? row['resolution'] ?? 'Server'}'),
    );
    final url = TextEditingController(text: '${row['stream_url'] ?? ''}');
    final ref = TextEditingController(text: '${row['referer'] ?? ''}');
    final org = TextEditingController(text: '${row['origin'] ?? ''}');
    final kid = TextEditingController(text: '${row['key_id'] ?? ''}');
    final key = TextEditingController(text: '${row['key_data'] ?? ''}');
    final webUrl = TextEditingController(text: '${row['webview_url'] ?? ''}');

    final sheetExit = FormExitHandle();
    bool sheetSaving = false;
    String? sheetError;
    try {
      String type = (row['stream_type'] ?? 'auto').toString();
      if (!streamTypes.containsKey(type)) type = 'auto';
      bool web = row['use_webview'] == true;

      final save = await showModalBottomSheet<bool>(
        context: context,
        isScrollControlled: true,
        useSafeArea: true,
        builder: (sheetContext) {
          return StatefulBuilder(
            builder: (context, setSheetState) {
              return UnsavedChangesGuard(
                  handle: sheetExit,
                  controllers: [name, url, ref, org, kid, key, webUrl],
                  busy: sheetSaving,
                  child: Padding(
                    padding: EdgeInsets.only(
                      left: 16,
                      right: 16,
                      top: 16,
                      bottom: MediaQuery.of(context).viewInsets.bottom + 20,
                    ),
                    child: SingleChildScrollView(
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Row(
                            children: [
                              const Expanded(
                                child: Text(
                                  'Edit Server',
                                  style: TextStyle(
                                    fontSize: 21,
                                    fontWeight: FontWeight.w900,
                                  ),
                                ),
                              ),
                              IconButton(
                                onPressed: sheetSaving
                                    ? null
                                    : () => Navigator.of(sheetContext)
                                        .maybePop(false),
                                icon: const Icon(Icons.close_rounded),
                              ),
                            ],
                          ),
                          const SizedBox(height: 12),
                          TextField(
                            controller: name,
                            decoration: const InputDecoration(
                              labelText: 'Server name',
                              hintText: 'Main / Backup / Server 1',
                            ),
                          ),
                          const SizedBox(height: 12),
                          DropdownButtonFormField<String>(
                            value: type,
                            decoration: const InputDecoration(
                              labelText: 'Stream type',
                            ),
                            items: streamTypes.entries
                                .map(
                                  (e) => DropdownMenuItem(
                                    value: e.key,
                                    child: Text(e.value),
                                  ),
                                )
                                .toList(),
                            onChanged: web
                                ? null
                                : (v) =>
                                    setSheetState(() => type = v ?? 'auto'),
                          ),
                          const SizedBox(height: 12),
                          TextField(
                            controller: url,
                            enabled: !web,
                            minLines: 2,
                            maxLines: 4,
                            onChanged: (value) {
                              final detected = detectStreamType(value);
                              if (detected != 'auto' && detected != type) {
                                setSheetState(() => type = detected);
                              }
                            },
                            decoration: const InputDecoration(
                              labelText: 'Stream URL',
                              helperText:
                                  'm3u8 / mpd / flv / mp4 is detected automatically.',
                            ),
                          ),
                          if (!web && type == 'dash') ...[
                            const SizedBox(height: 12),
                            _dashCompatibilityNotice(context),
                          ],
                          const SizedBox(height: 8),
                          ExpansionTile(
                            tilePadding: EdgeInsets.zero,
                            title: const Text(
                              'Advanced options',
                              style: TextStyle(fontWeight: FontWeight.w800),
                            ),
                            subtitle: const Text(
                              'Only open this if the source requires headers, ClearKey or WebView.',
                            ),
                            children: [
                              const SizedBox(height: 8),
                              TextField(
                                controller: ref,
                                decoration: const InputDecoration(
                                  labelText: 'Referer header',
                                  hintText: 'Optional',
                                ),
                              ),
                              const SizedBox(height: 12),
                              TextField(
                                controller: org,
                                decoration: const InputDecoration(
                                  labelText: 'Origin header',
                                  hintText: 'Optional',
                                ),
                              ),
                              const SizedBox(height: 12),
                              if (!web && type == 'dash') ...[
                                TextField(
                                  controller: kid,
                                  decoration: const InputDecoration(
                                    labelText: 'ClearKey keyID',
                                    hintText: 'Optional',
                                  ),
                                ),
                                const SizedBox(height: 12),
                                TextField(
                                  controller: key,
                                  decoration: const InputDecoration(
                                    labelText: 'ClearKey keyData',
                                    hintText: 'Optional',
                                  ),
                                ),
                              ],
                              const SizedBox(height: 4),
                              SwitchListTile.adaptive(
                                contentPadding: EdgeInsets.zero,
                                title: const Text('Use WebView instead'),
                                value: web,
                                onChanged: (v) => setSheetState(() => web = v),
                              ),
                              if (web) ...[
                                const SizedBox(height: 6),
                                TextField(
                                  controller: webUrl,
                                  decoration: const InputDecoration(
                                    labelText: 'WebView URL',
                                  ),
                                ),
                              ],
                            ],
                          ),
                          if (sheetError != null)
                            Padding(
                                padding:
                                    const EdgeInsets.symmetric(vertical: 8),
                                child: Text(sheetError!,
                                    style: TextStyle(
                                        color: Theme.of(context)
                                            .colorScheme
                                            .error))),
                          const SizedBox(height: 14),
                          SizedBox(
                            width: double.infinity,
                            child: FilledButton.icon(
                              onPressed: sheetSaving
                                  ? null
                                  : () async {
                                      final effectiveType = web
                                          ? 'auto'
                                          : detectStreamType(url.text,
                                              fallback: type);
                                      final validation = _validateInput(
                                          web ? webUrl.text : url.text,
                                          effectiveType,
                                          ref.text,
                                          org.text,
                                          kid.text,
                                          key.text,
                                          web: web);
                                      if (validation != null) {
                                        setSheetState(
                                            () => sheetError = validation);
                                        return;
                                      }
                                      setSheetState(() {
                                        sheetSaving = true;
                                        sheetError = null;
                                      });
                                      try {
                                        final changedPlayback =
                                            (web ? '' : url.text.trim()) !=
                                                    (row['stream_url'] ?? '') ||
                                                effectiveType !=
                                                    row['stream_type'] ||
                                                nullable(ref.text) !=
                                                    row['referer'] ||
                                                nullable(org.text) !=
                                                    row['origin'] ||
                                                nullable(kid.text) !=
                                                    row['key_id'] ||
                                                nullable(key.text) !=
                                                    row['key_data'];
                                        var edit = Supabase.instance.client
                                            .from('stream_links')
                                            .update({
                                              if (changedPlayback)
                                                'channel_id': null,
                                              if (changedPlayback)
                                                'channel_line_id': null,
                                              'label': name.text.trim().isEmpty
                                                  ? 'Server'
                                                  : name.text.trim(),
                                              'resolution':
                                                  name.text.trim().isEmpty
                                                      ? 'Server'
                                                      : name.text.trim(),
                                              'stream_type': effectiveType,
                                              'stream_url':
                                                  web ? '' : url.text.trim(),
                                              'referer': nullable(ref.text),
                                              'origin': nullable(org.text),
                                              'key_id': !web &&
                                                      effectiveType == 'dash'
                                                  ? nullable(kid.text)
                                                  : null,
                                              'key_data': !web &&
                                                      effectiveType == 'dash'
                                                  ? nullable(key.text)
                                                  : null,
                                              'use_webview': web,
                                              'webview_url': web
                                                  ? nullable(webUrl.text)
                                                  : null,
                                              'send_notification': false,
                                            })
                                            .eq('id', row['id'])
                                            .eq('stream_url',
                                                row['stream_url'] ?? '');
                                        for (final field in [
                                          'label',
                                          'resolution',
                                          'stream_type',
                                          'referer',
                                          'origin',
                                          'key_id',
                                          'key_data',
                                          'use_webview',
                                          'webview_url'
                                        ]) {
                                          if (row.containsKey(field))
                                            edit = row[field] == null
                                                ? edit.isFilter(field, null)
                                                : edit.eq(field, row[field]);
                                        }
                                        await edit
                                            .select('id')
                                            .single()
                                            .timeout(
                                                const Duration(seconds: 12));
                                        if (sheetContext.mounted)
                                          sheetExit.savedPop(
                                              sheetContext, true);
                                      } catch (_) {
                                        if (sheetContext.mounted)
                                          setSheetState(() => sheetError =
                                              'Save was not confirmed. Your changes are kept. Refresh the server before retrying.');
                                      } finally {
                                        if (sheetContext.mounted)
                                          setSheetState(
                                              () => sheetSaving = false);
                                      }
                                    },
                              icon: const Icon(Icons.save_rounded),
                              label: Text(
                                  sheetSaving ? 'SAVING…' : 'SAVE CHANGES'),
                            ),
                          ),
                        ],
                      ),
                    ),
                  ));
            },
          );
        },
      );

      if (save == true && mounted) {
        message('Server updated.');
        reloadLinks();
      }
    } finally {
      sheetExit.dispose();
      for (final controller in [name, url, ref, org, kid, key, webUrl]) {
        controller.dispose();
      }
    }
  }

  Widget _serverCard(
    Map<String, dynamic> row,
    ColorScheme colors, {
    int displayIndex = 0,
  }) {
    final rawName = conciseMatchLineLabel(
        '${row['label'] ?? row['resolution'] ?? 'Server'}');
    final name = RegExp(r'^YYZB\b', caseSensitive: false).hasMatch(rawName)
        ? englishStreamLabel(rawName, index: displayIndex)
        : rawName;
    final streamKey = (row['stream_type'] ?? 'auto').toString();
    final type = row['use_webview'] == true
        ? 'WEBVIEW'
        : streamTypes[streamKey] ?? 'Auto / Direct';
    final url = row['use_webview'] == true
        ? '${row['webview_url'] ?? ''}'
        : '${row['stream_url'] ?? ''}';
    final active = row['is_active'] == true;
    final health = (row['health_status'] ?? 'unknown').toString();
    final latency = (row['health_latency_ms'] as num?)?.toInt();
    final checking = checkingLinks.contains(row['id'].toString());
    final keyedDash = streamKey == 'dash' &&
        ((row['key_id']?.toString().trim().isNotEmpty ?? false) ||
            (row['key_data']?.toString().trim().isNotEmpty ?? false));

    return Padding(
      padding: const EdgeInsets.only(bottom: 9),
      child: Card(
        margin: EdgeInsets.zero,
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(18),
          side: BorderSide(
            color: colors.outlineVariant.withValues(alpha: .5),
          ),
        ),
        child: Padding(
          padding: const EdgeInsets.all(12),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Row(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Container(
                    width: 40,
                    height: 40,
                    decoration: BoxDecoration(
                      color: colors.primary.withValues(alpha: .10),
                      borderRadius: BorderRadius.circular(12),
                    ),
                    alignment: Alignment.center,
                    child: Icon(
                      keyedDash ? Icons.lock_rounded : Icons.dns_rounded,
                      color: colors.primary,
                    ),
                  ),
                  const SizedBox(width: 10),
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(
                          name,
                          maxLines: 2,
                          overflow: TextOverflow.ellipsis,
                          style: const TextStyle(
                            fontSize: 14.5,
                            fontWeight: FontWeight.w900,
                          ),
                        ),
                        const SizedBox(height: 6),
                        Wrap(
                          spacing: 6,
                          runSpacing: 6,
                          crossAxisAlignment: WrapCrossAlignment.center,
                          children: [
                            Container(
                              padding: const EdgeInsets.symmetric(
                                horizontal: 8,
                                vertical: 4,
                              ),
                              decoration: BoxDecoration(
                                color: colors.surfaceContainerHighest,
                                borderRadius: BorderRadius.circular(999),
                              ),
                              child: Text(
                                type,
                                style: TextStyle(
                                  fontSize: 10,
                                  fontWeight: FontWeight.w800,
                                  color: colors.onSurfaceVariant,
                                ),
                              ),
                            ),
                            _HealthChip(
                              status: health,
                              latencyMs: latency,
                            ),
                          ],
                        ),
                        const SizedBox(height: 5),
                        Text(
                          'Link: ${url.trim().isNotEmpty ? 'FOUND' : 'MISSING'}'
                          ' • HTTP: ${health == 'unknown' ? 'NOT CHECKED' : health == 'healthy' || health == 'slow' ? 'REACHABLE' : 'NOT REACHABLE'}'
                          ' • Video: NOT VERIFIED',
                          style: TextStyle(
                            fontSize: 10.5,
                            color: colors.onSurfaceVariant,
                            fontWeight: FontWeight.w700,
                          ),
                        ),
                        Text(
                          'HTTP check cannot confirm decoded video. Open player to test.',
                          style: TextStyle(
                              fontSize: 10, color: colors.onSurfaceVariant),
                        ),
                      ],
                    ),
                  ),
                  PopupMenuButton<String>(
                    tooltip: 'Server actions',
                    onSelected: (value) {
                      if (value == 'edit') {
                        editLink(row);
                      } else if (value == 'delete') {
                        deleteLink(row['id'].toString());
                      }
                    },
                    itemBuilder: (_) => const [
                      PopupMenuItem(
                        value: 'edit',
                        child: ListTile(
                          dense: true,
                          leading: Icon(Icons.edit_rounded),
                          title: Text('Edit'),
                        ),
                      ),
                      PopupMenuItem(
                        value: 'delete',
                        child: ListTile(
                          dense: true,
                          leading: Icon(
                            Icons.delete_outline_rounded,
                            color: Colors.redAccent,
                          ),
                          title: Text('Delete'),
                        ),
                      ),
                    ],
                  ),
                ],
              ),
              if (keyedDash) ...[
                const SizedBox(height: 9),
                Container(
                  width: double.infinity,
                  padding: const EdgeInsets.symmetric(
                    horizontal: 10,
                    vertical: 8,
                  ),
                  decoration: BoxDecoration(
                    color: colors.primaryContainer.withValues(alpha: .45),
                    borderRadius: BorderRadius.circular(12),
                  ),
                  child: Text(
                    'ClearKey DASH • Uses the saved Key ID and Key Data. '
                    'Playback depends on the device and source.',
                    style: TextStyle(
                      color: colors.onPrimaryContainer,
                      fontSize: 11,
                      fontWeight: FontWeight.w800,
                    ),
                  ),
                ),
              ],
              if (url.trim().isNotEmpty) ...[
                const SizedBox(height: 9),
                Text(
                  url,
                  maxLines: 1,
                  overflow: TextOverflow.ellipsis,
                  style: TextStyle(
                    fontSize: 11.5,
                    color: colors.onSurfaceVariant,
                  ),
                ),
              ],
              const SizedBox(height: 9),
              Row(
                children: [
                  Expanded(
                    child: OutlinedButton.icon(
                      onPressed: checking
                          ? null
                          : () => checkHealth(row['id'].toString()),
                      icon: checking
                          ? const SizedBox(
                              width: 16,
                              height: 16,
                              child: CircularProgressIndicator(strokeWidth: 2),
                            )
                          : const Icon(Icons.monitor_heart_rounded, size: 18),
                      label: Text(checking ? 'CHECKING' : 'CHECK'),
                    ),
                  ),
                  const SizedBox(width: 10),
                  const Text(
                    'Active',
                    style: TextStyle(fontWeight: FontWeight.w800),
                  ),
                  const SizedBox(width: 4),
                  Switch.adaptive(
                    value: active,
                    onChanged: updatingLinks.contains(row['id'].toString())
                        ? null
                        : (value) => setActive(row['id'].toString(), value),
                  ),
                ],
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _input(String label, TextEditingController controller,
          {bool enabled = true}) =>
      Padding(
        padding: const EdgeInsets.only(bottom: 14),
        child: TextField(
          controller: controller,
          enabled: enabled,
          // Some Android/ColorOS builds replace Gboard with their secure
          // keyboard for URL-classified fields. Links are not passwords, so
          // keep the normal text IME while retaining URL validation on save.
          keyboardType: TextInputType.text,
          textInputAction: TextInputAction.next,
          autocorrect: false,
          // Flutter maps false to Android VISIBLE_PASSWORD. Some phone IMEs
          // then force their secure keyboard, even for ordinary URL fields.
          enableSuggestions: true,
          onChanged: controller == link
              ? (value) => setState(() => streamType = detectStreamType(value))
              : null,
          decoration: InputDecoration(
              labelText: label,
              border: const OutlineInputBorder(),
              suffixIcon: IconButton(
                  tooltip: 'Clear $label',
                  icon: const Icon(Icons.close, size: 20),
                  onPressed: enabled
                      ? () {
                          controller.clear();
                          if (controller == link)
                            setState(() => streamType = 'auto');
                        }
                      : null)),
        ),
      );

  @override
  Widget build(BuildContext context) {
    final colors = Theme.of(context).colorScheme;
    return UnsavedChangesGuard(
        handle: _formExit,
        controllers: [
          serverName,
          link,
          referer,
          origin,
          keyId,
          keyData,
          webViewUrl
        ],
        dirty: () =>
            _hasDraft || _drafts.values.any((d) => (d['url'] ?? '').isNotEmpty),
        busy: loading,
        child: Scaffold(
          appBar: AppBar(
              title: Text(matchId == null ? 'Live Links' : 'Live Links Upload'),
              leading: matchId == null
                  ? null
                  : BackButton(onPressed: () => selectMatch(null))),
          body: FutureBuilder<List<Map<String, dynamic>>>(
              future: _matchesFuture,
              builder: (context, snapshot) {
                if (snapshot.hasError)
                  return _loadFailure('Could not load matches.', reloadMatches);
                if (!snapshot.hasData)
                  return const Center(child: CircularProgressIndicator());
                final matches = snapshot.data!;
                final selected =
                    matches.where((m) => m['id'] == matchId).toList();
                if (matchId == null || selected.isEmpty) {
                  if (matches.isEmpty)
                    return const Center(
                        child: Text('No published matches yet.'));
                  return ListView.builder(
                      padding: const EdgeInsets.all(12),
                      itemCount: matches.length +
                          (selectedChannelName == null ? 0 : 1),
                      itemBuilder: (_, index) {
                        if (selectedChannelName != null && index == 0) {
                          return Padding(
                            padding: const EdgeInsets.only(bottom: 12),
                            child:
                                Text('Choose a match for $selectedChannelName'),
                          );
                        }
                        final row = matches[
                            index - (selectedChannelName == null ? 0 : 1)];
                        return Padding(
                          padding: const EdgeInsets.only(bottom: 8),
                          child: MatchStreamCard(
                              match: row,
                              onTap: () => selectMatch(row['id'] as String)),
                        );
                      });
                }
                return ListView(
                    padding: const EdgeInsets.fromLTRB(16, 8, 16, 28),
                    children: [
                      Text(
                          '${englishKnownFootballName(selected.first['home_team'].toString())} vs ${englishKnownFootballName(selected.first['away_team'].toString())}',
                          style: Theme.of(context).textTheme.titleMedium),
                      const SizedBox(height: 18),
                      OutlinedButton.icon(
                        onPressed: loading ? null : chooseChannel,
                        icon: const Icon(Icons.tv),
                        label: const Text('USE CHANNEL'),
                      ),
                      const SizedBox(height: 14),
                      _input('Resolution', serverName),
                      _input('Link', link, enabled: !useWebView),
                      _input('Referer', referer),
                      _input('Origin', origin),
                      _input('keyID', keyId, enabled: !useWebView),
                      _input('keyData', keyData, enabled: !useWebView),
                      const SizedBox(height: 12),
                      FilledButton.icon(
                          onPressed: loading ? null : addLink,
                          icon: const Icon(Icons.add_link),
                          label: Text(loading ? 'SAVING...' : 'SAVE LINK')),
                      const SizedBox(height: 22),
                      _autoGuideCard(colors),
                      if (matchId != null) ...[
                        const SizedBox(height: 22),
                        Wrap(
                          alignment: WrapAlignment.spaceBetween,
                          crossAxisAlignment: WrapCrossAlignment.center,
                          children: [
                            Text(
                              'Existing Servers',
                              style: Theme.of(context)
                                  .textTheme
                                  .titleLarge
                                  ?.copyWith(
                                    fontWeight: FontWeight.w900,
                                  ),
                            ),
                            OutlinedButton.icon(
                              onPressed:
                                  testingHealth ? null : () => testHealth(),
                              icon: testingHealth
                                  ? const SizedBox(
                                      width: 16,
                                      height: 16,
                                      child: CircularProgressIndicator(
                                          strokeWidth: 2),
                                    )
                                  : const Icon(Icons.monitor_heart_rounded),
                              label: const Text('TEST ALL'),
                            ),
                            const SizedBox(width: 6),
                            IconButton(
                              tooltip: 'Refresh',
                              onPressed: () {
                                setState(() {
                                  _matchesFuture = _startMatchesLoad();
                                  _linksFuture = _startLinksLoad();
                                  if (matchId != null) {
                                    _epgFuture = _syncEpg(matchId!);
                                  }
                                });
                              },
                              icon: const Icon(Icons.refresh_rounded),
                            ),
                          ],
                        ),
                        const SizedBox(height: 8),
                        FutureBuilder<List<Map<String, dynamic>>>(
                          key: ValueKey(matchId),
                          future: _linksFuture ??= _startLinksLoad(),
                          builder: (context, linkSnapshot) {
                            if (linkSnapshot.hasError) {
                              return _loadFailure(
                                  'Could not load servers.', reloadLinks);
                            }
                            if (linkSnapshot.connectionState !=
                                    ConnectionState.done ||
                                !linkSnapshot.hasData) {
                              return const Center(
                                child: Padding(
                                  padding: EdgeInsets.all(20),
                                  child: CircularProgressIndicator(),
                                ),
                              );
                            }

                            final rows = linkSnapshot.data!;
                            if (rows.isEmpty) {
                              return Card(
                                child: Padding(
                                  padding: const EdgeInsets.all(18),
                                  child: Text(
                                    'No servers added yet.',
                                    style: TextStyle(
                                      color: colors.onSurfaceVariant,
                                    ),
                                  ),
                                ),
                              );
                            }

                            return Column(
                              children: rows
                                  .asMap()
                                  .entries
                                  .map((entry) => _serverCard(
                                      entry.value, colors,
                                      displayIndex: entry.key))
                                  .toList(),
                            );
                          },
                        ),
                      ],
                    ]);
              }),
        ));
  }

  Widget _loadFailure(String text, VoidCallback retry) => Center(
        child: Padding(
          padding: const EdgeInsets.all(20),
          child: Column(mainAxisSize: MainAxisSize.min, children: [
            Text(text),
            const SizedBox(height: 12),
            FilledButton(onPressed: retry, child: const Text('Retry')),
          ]),
        ),
      );
}

class _HealthChip extends StatelessWidget {
  const _HealthChip({
    required this.status,
    required this.latencyMs,
  });

  final String status;
  final int? latencyMs;

  @override
  Widget build(BuildContext context) {
    final normalized = status.toLowerCase();
    final color = switch (normalized) {
      'healthy' => Colors.green,
      'slow' => Colors.orange,
      'failed' => Colors.redAccent,
      _ => Colors.blueGrey,
    };

    final label =
        normalized == 'unknown' ? 'UNKNOWN' : normalized.toUpperCase();

    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 9, vertical: 5),
      decoration: BoxDecoration(
        color: color.withValues(alpha: .10),
        borderRadius: BorderRadius.circular(999),
        border: Border.all(color: color.withValues(alpha: .30)),
      ),
      child: Text(
        latencyMs == null ? label : '$label • ${latencyMs}ms',
        style: TextStyle(
          color: color,
          fontSize: 11,
          fontWeight: FontWeight.w900,
        ),
      ),
    );
  }
}
