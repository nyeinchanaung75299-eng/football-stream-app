import 'dart:async';
import 'dart:convert';

import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'package:package_info_plus/package_info_plus.dart';

import 'analytics_service.dart';
import 'app_update_installer.dart';

const _vpnFreeViewerOrigin = 'https://nca.nyeinchanaung.us.ci';

@visibleForTesting
String vpnFreeUpdateUrl(String value) {
  final trimmed = value.trim();
  final uri = Uri.tryParse(trimmed);
  if (uri == null ||
      uri.host != Uri.parse(_vpnFreeViewerOrigin).host ||
      !uri.path.startsWith('/football-stream-app/releases/')) {
    return trimmed;
  }
  return uri
      .replace(
        scheme: 'https',
        host: 'nyeinchanaung75299-eng.github.io',
        port: null,
      )
      .toString();
}

const _viewerReleaseApkPath =
    '/nyeinchanaung75299-eng/football-stream-app/feed/public/releases/'
    'NCA-arm64-v8a-latest.apk';

/// Refuse unrelated or corrupted manifests before comparing version codes.
@visibleForTesting
bool validViewerRelease(Map<String, dynamic> release) {
  final uri = Uri.tryParse(release['apk_url']?.toString() ?? '');
  final digest = (release['sha256'] ?? '').toString().trim().toLowerCase();
  final version = (release['version_name'] ?? '').toString().trim();
  final size = int.tryParse(release['size_bytes']?.toString() ?? '') ?? 0;
  final build = int.tryParse(release['build_number']?.toString() ?? '') ?? 0;
  return (release['app'] == null || release['app'] == 'nca_viewer') &&
      release['abi'] == 'arm64-v8a' &&
      uri != null &&
      uri.scheme == 'https' &&
      uri.host == 'raw.githubusercontent.com' &&
      uri.path == _viewerReleaseApkPath &&
      !uri.hasQuery &&
      !uri.hasFragment &&
      RegExp(r'^[0-9a-f]{64}$').hasMatch(digest) &&
      RegExp(r'^\d+\.\d+\.\d+$').hasMatch(version) &&
      size > 0 &&
      size <= 45 * 1024 * 1024 &&
      build > 0;
}

class AppUpdateService {
  AppUpdateService._();

  static bool _checked = false;
  static bool _downloading = false;

  // Prefer the release feed written atomically with signed APKs; Pages lags.
  static const _manifestUrls = <String>[
    'https://raw.githubusercontent.com/'
        'nyeinchanaung75299-eng/football-stream-app/'
        'feed/public/releases/latest.json',
    'https://nyeinchanaung75299-eng.github.io/'
        'football-stream-app/releases/latest.json',
    '$_vpnFreeViewerOrigin/football-stream-app/releases/latest.json',
  ];

  @visibleForTesting
  static List<String> get manifestUrls => _manifestUrls;

  static Future<String> versionSummary() async {
    try {
      final info = await PackageInfo.fromPlatform();
      final currentVersion = info.version.trim().isEmpty
          ? '9.8.0'
          : info.version.trim();
      final currentBuild = info.buildNumber.trim();
      final installed = currentBuild.isEmpty
          ? 'V$currentVersion'
          : 'V$currentVersion ($currentBuild)';

      if (kIsWeb || defaultTargetPlatform != TargetPlatform.android) {
        return 'Installed $installed';
      }

      final stamp = DateTime.now().millisecondsSinceEpoch;
      for (final base in _manifestUrls) {
        try {
          final response = await http
              .get(
                Uri.parse('$base?t=$stamp'),
                headers: const {
                  'Accept': 'application/json',
                  'Cache-Control': 'no-cache',
                },
              )
              .timeout(const Duration(seconds: 5));

          if (response.statusCode < 200 || response.statusCode >= 300) {
            continue;
          }

          final decoded = jsonDecode(response.body);
          if (decoded is! Map ||
              !validViewerRelease(Map<String, dynamic>.from(decoded))) {
            continue;
          }

          final latestVersion =
              decoded['version_name']?.toString().trim() ?? '';
          final latestBuild = decoded['build_number']?.toString().trim() ?? '';
          if (latestVersion.isEmpty && latestBuild.isEmpty) {
            return 'Installed $installed';
          }

          final latest = latestBuild.isEmpty
              ? 'V$latestVersion'
              : 'V$latestVersion ($latestBuild)';
          return 'Installed $installed • Latest $latest';
        } catch (_) {}
      }

      return 'Installed $installed • Latest unavailable';
    } catch (_) {
      return 'Version unavailable';
    }
  }

  static Future<void> check(BuildContext context, {bool force = false}) async {
    if (kIsWeb || defaultTargetPlatform != TargetPlatform.android) {
      return;
    }
    if (_checked && !force) return;
    _checked = true;

    await AnalyticsService.capture(
      'update check',
      properties: {'manual': force},
    );

    try {
      final info = await PackageInfo.fromPlatform();
      final currentBuild = int.tryParse(info.buildNumber) ?? 0;
      final stamp = DateTime.now().millisecondsSinceEpoch;
      Map<dynamic, dynamic>? data;

      for (final base in _manifestUrls) {
        try {
          final response = await http
              .get(
                Uri.parse('$base?t=$stamp'),
                headers: const {
                  'Accept': 'application/json',
                  'Cache-Control': 'no-cache',
                },
              )
              .timeout(const Duration(seconds: 8));

          if (response.statusCode < 200 || response.statusCode >= 300) {
            continue;
          }

          final decoded = jsonDecode(response.body);
          if (decoded is Map) {
            final candidate = Map<String, dynamic>.from(decoded);
            if (!validViewerRelease(candidate)) continue;
            data = candidate;
            break;
          }
        } catch (_) {}
      }

      if (data == null) {
        await AnalyticsService.capture(
          'update check failed',
          properties: {'manual': force, 'reason': 'manifest_unavailable'},
        );
        if (force && context.mounted) {
          ScaffoldMessenger.of(context).showSnackBar(
            const SnackBar(
              content: Text('Could not check for updates right now.'),
            ),
          );
        }
        return;
      }

      final latestBuild =
          int.tryParse(data['build_number']?.toString() ?? '') ?? 0;
      if (latestBuild <= currentBuild && !force) return;

      final version = data['version_name']?.toString().trim().isNotEmpty == true
          ? data['version_name'].toString()
          : 'new version';
      final apkUrl = vpnFreeUpdateUrl(data['apk_url']?.toString().trim() ?? '');
      final apkSha256 = data['sha256']?.toString().trim().toLowerCase() ?? '';
      final notes = data['notes']?.toString().trim() ?? '';
      final mandatory = data['mandatory'] == true;
      final validHash = RegExp(r'^[0-9a-f]{64}$').hasMatch(apkSha256);

      if (apkUrl.isEmpty || !validHash) {
        await AnalyticsService.capture(
          'update check failed',
          properties: {
            'manual': force,
            'reason': apkUrl.isEmpty
                ? 'apk_url_missing'
                : 'apk_sha256_missing_or_invalid',
          },
        );
        if (force && context.mounted) {
          ScaffoldMessenger.of(context).showSnackBar(
            const SnackBar(
              content: Text('The update package could not be verified.'),
            ),
          );
        }
        return;
      }
      if (!context.mounted) return;

      await AnalyticsService.capture(
        'update available',
        properties: {
          'manual': force,
          'current_build': currentBuild,
          'latest_build': latestBuild,
          'version': version,
          'mandatory': mandatory,
        },
      );

      await showDialog<void>(
        context: context,
        barrierDismissible: !mandatory,
        builder: (dialogContext) => AlertDialog(
          icon: const Icon(Icons.system_update_alt_rounded),
          title: Text(
            'NCA $version${latestBuild > currentBuild ? ' available' : ''}',
          ),
          content: Text(
            latestBuild <= currentBuild
                ? 'This is the current published release. Save or share its verified APK.'
                : notes.isEmpty
                ? 'A newer version of NCA is ready. Update now?'
                : notes,
          ),
          actions: [
            if (!mandatory)
              TextButton(
                onPressed: () => Navigator.pop(dialogContext),
                child: const Text('Later'),
              ),
            TextButton(
              onPressed: () {
                Navigator.pop(dialogContext);
                _download(context, apkUrl, apkSha256, action: ApkAction.save);
              },
              child: const Text('Save APK'),
            ),
            TextButton(
              onPressed: () {
                Navigator.pop(dialogContext);
                _download(context, apkUrl, apkSha256, action: ApkAction.share);
              },
              child: const Text('Share APK'),
            ),
            if (latestBuild > currentBuild)
              FilledButton.icon(
                onPressed: () {
                  AnalyticsService.capture(
                    'update accepted',
                    properties: {
                      'latest_build': latestBuild,
                      'version': version,
                    },
                  );
                  Navigator.pop(dialogContext);
                  _download(context, apkUrl, apkSha256);
                },
                icon: const Icon(Icons.download_rounded),
                label: const Text('Update now'),
              ),
          ],
        ),
      );
    } catch (_) {
      await AnalyticsService.capture(
        'update check failed',
        properties: {'manual': force, 'reason': 'unexpected_error'},
      );
      if (force && context.mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(
            content: Text('Could not check for updates right now.'),
          ),
        );
      }
    }
  }

  static Future<void> _download(
    BuildContext context,
    String apkUrl,
    String apkSha256, {
    ApkAction action = ApkAction.install,
  }) async {
    if (_downloading || !context.mounted) return;
    _downloading = true;
    final progress = ValueNotifier<double>(0);
    final navigator = Navigator.of(context, rootNavigator: true);
    final route = DialogRoute<void>(
      context: context,
      barrierDismissible: false,
      builder: (dialogContext) => PopScope(
        canPop: false,
        child: ValueListenableBuilder<double>(
          valueListenable: progress,
          builder: (context, value, _) => AlertDialog(
            title: const Text('Downloading verified NCA APK'),
            content: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                LinearProgressIndicator(
                  value: value > 0 && value < 1 ? value : null,
                ),
                const SizedBox(height: 12),
                Text(
                  value > 0
                      ? '${(value * 100).clamp(0, 100).toStringAsFixed(0)}%'
                      : 'Starting download…',
                ),
              ],
            ),
          ),
        ),
      ),
    );
    unawaited(navigator.push(route));

    try {
      await AnalyticsService.capture('update download started');
      await downloadAndInstallApk(
        apkUrl,
        expectedSha256: apkSha256,
        action: action,
        sharePositionOrigin: const Rect.fromLTWH(0, 0, 1, 1),
        onProgress: (value) => progress.value = value,
      );
      await AnalyticsService.capture(
        'update download completed',
        properties: {'sha256_verified': true},
      );
    } catch (error) {
      final verificationFailure =
          error.toString().toLowerCase().contains('sha-256') ||
          error.toString().toLowerCase().contains('verified');
      await AnalyticsService.capture(
        'update download failed',
        properties: {
          'reason': verificationFailure
              ? 'sha256_verification_failed'
              : 'download_or_installer_failed',
        },
      );
      if (context.mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            content: Text(
              verificationFailure
                  ? 'Update verification failed. The APK was not installed.'
                  : 'Update download failed. Check your connection and try again.',
            ),
          ),
        );
      }
    } finally {
      // Close only this progress dialog, even if the app navigated meanwhile.
      if (route.isActive) navigator.removeRoute(route);
      progress.dispose();
      _downloading = false;
    }
  }
}
