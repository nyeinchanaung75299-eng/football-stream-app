import 'package:flutter_test/flutter_test.dart';
import 'package:http/http.dart' as http;
import 'package:http/testing.dart';
import 'package:football_viewer/backend_endpoint.dart';
import 'package:football_viewer/network_endpoints.dart';

void main() {
  setUp(() => rememberVerifiedPublicApiBase(cloudflarePublicBase));

  test('Cloudflare first for public data, Vercel retained as fallback', () {
    final bases = publicApiBases(primary: 'https://football-api.example/');
    expect(bases.first, 'https://football-api.example');
    expect(bases.last, vercelBackupBase);
    expect(bases.toSet().length, bases.length);
  });

  test(
    'Only a configured, recently healthy public API can lead the route list',
    () {
      final original = publicApiBases();
      expect(original.first, cloudflarePublicBase);
      rememberVerifiedPublicApiBase('https://untrusted.invalid');
      expect(publicApiBases().first, cloudflarePublicBase);
      rememberVerifiedPublicApiBase('https://football-api.nyeinchanaung.us.ci');
      expect(
        publicApiBases().first,
        'https://football-api.nyeinchanaung.us.ci',
      );
      expect(publicApiBases().contains(vercelBackupBase), isTrue);
      expect(publicApiBases().toSet().length, publicApiBases().length);
      expect(
        publicApiBases().contains(
          'https://football-public-api.nyeinchanaung75299-eng.workers.dev',
        ),
        isFalse,
      );
    },
  );

  test(
    'Cloudflare Auth probes include the public API key required by GoTrue',
    () async {
      await http.runWithClient(
        () async {
          final result = await resolveSupabaseUrl(
            directUrl: 'https://database.example',
            publishableKey: 'test-public-key',
          );
          expect(result, cloudflarePublicBase);
          expect(usesVercelBackend, isFalse);
        },
        () => MockClient((request) async {
          if (request.url.host == Uri.parse(cloudflarePublicBase).host) {
            expect(request.url.path, '/auth/v1/health');
            if (request.headers['apikey'] != 'test-public-key') {
              return http.Response('{}', 401);
            }
            return http.Response('{"name":"GoTrue"}', 200);
          }
          throw http.ClientException('Blocked alternative');
        }),
      );
    },
  );

  test(
    'a fast rejected health response cannot beat a healthy backend',
    () async {
      await http.runWithClient(
        () async {
          final result = await resolveSupabaseUrl(
            directUrl: 'https://database.example',
            publishableKey: 'test-public-key',
          );
          expect(result, 'https://database.example');
        },
        () => MockClient((request) async {
          if (request.url.host == 'database.example') {
            await Future<void>.delayed(Duration.zero);
            return http.Response('{}', 200);
          }
          return http.Response('{}', 401);
        }),
      );
    },
  );

  test(
    'Vercel backend health enables Auth/REST when the other routes are blocked',
    () async {
      await http.runWithClient(
        () async {
          final result = await resolveSupabaseUrl(
            directUrl: 'https://database.example/',
            publishableKey: 'test-public-key',
          );
          expect(result, vercelBackupBase);
          expect(usesVercelBackend, isTrue);
          expect(
            publicApiBases().first,
            cloudflarePublicBase,
            reason: 'VPN-free metadata routing stays independent of Auth.',
          );
        },
        () => MockClient((request) async {
          if (request.url.host == Uri.parse(vercelBackupBase).host) {
            expect(request.url.path, '/backend-health');
            expect(request.headers['apikey'], 'test-public-key');
            return http.Response('{"name":"GoTrue"}', 200);
          }
          throw http.ClientException('Blocked fixture route');
        }),
      );
    },
  );

  test(
    'A reachable public health response cannot select an unhealthy Auth relay',
    () async {
      await http.runWithClient(
        () async {
          final result = await resolveSupabaseUrl(
            directUrl: 'https://database.example/',
            publishableKey: 'test-public-key',
          );
          expect(result, 'https://database.example');
          expect(usesVercelBackend, isFalse);
        },
        () => MockClient((request) async {
          if (request.url.host == 'database.example') {
            await Future<void>.delayed(Duration.zero);
            return http.Response('{}', 200);
          }
          return http.Response(
            '{"ok":true,"service":"football-public-api"}',
            200,
          );
        }),
      );
    },
  );

  test(
    'All failed routes finish with the original endpoint; API lists never duplicate the backup',
    () async {
      await http.runWithClient(() async {
        final result = await resolveSupabaseUrl(
          directUrl: 'https://database.example/',
          publishableKey: 'test-public-key',
        );
        expect(result, 'https://database.example');
      }, () => MockClient((_) async => http.Response('{}', 503)));
      final routes = publicApiBases(primary: '$vercelBackupBase/');
      expect(routes.where((base) => base == vercelBackupBase).length, 1);
    },
  );
}
