import 'dart:convert';

import 'package:flutter/material.dart';
import 'package:football_viewer/viewer_tab_cache.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:http/http.dart' as http;
import 'package:http/testing.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:football_viewer/screens/source_browser_page.dart';
import 'package:football_viewer/widgets/premium_bottom_nav.dart';
import 'package:football_viewer/widgets/source_match_filters.dart';

List<Map<String, dynamic>> _fixtures() {
  final now = DateTime.now();
  final today = DateTime(now.year, now.month, now.day, 23, 59);
  return [
    {
      'source_id': 'today-featured',
      'league': 'English Premier League',
      'home_team': 'Arsenal',
      'away_team': 'Leeds',
      'hot': true,
      'match_time': today.toUtc().toIso8601String(),
      'anchors': [
        {'room_num': 'real-streamer-room'},
      ],
    },
    {
      'source_id': 'schedule-without-room',
      'league': 'Bundesliga',
      'home_team': 'Dortmund',
      'away_team': 'Mainz',
      'match_time': today.toUtc().toIso8601String(),
      'anchors': [],
    },
    {
      'source_id': 'tomorrow',
      'league': 'English Premier League',
      'home_team': 'Chelsea',
      'away_team': 'Bournemouth',
      'match_time': today
          .add(const Duration(days: 1))
          .toUtc()
          .toIso8601String(),
      'anchors': [
        {'room_num': 'tomorrow-room'},
      ],
    },
  ];
}

void main() {
  setUp(() {
    ViewerTabCache.clearForTesting();
    SharedPreferences.setMockInitialValues({});
  });

  testWidgets('Live 2 lists repository fixtures without depending on main Live or inventing kickoff times', (tester) async {
    await http.runWithClient(() async {
      await tester.pumpWidget(const MaterialApp(home: SourceBrowserPage(source: 'repository')));
      await tester.pumpAndSettle();
      expect(find.text('Everton'), findsOneWidget);
      expect(find.text('Coventry City'), findsOneWidget);
      expect(tester.widget<PremiumBottomNav>(find.byType(PremiumBottomNav)).selectedIndex, 1);
      expect(find.text('Live 2'),findsOneWidget);
      expect(find.text('Totalsportek'),findsNothing);
      expect(tester.takeException(), isNull);
      await tester.pumpWidget(const SizedBox.shrink());
    }, () => MockClient((request) async {
      expect(request.url.path, '/sources/repository/matches');
      return http.Response(jsonEncode({'source': 'repository', 'matches': [{
        'source': 'repository', 'source_id': 'repo:match:aaaaaaaaaaaaaaaaaaaaaaaaaaaa', 'league': 'Premier League',
        'home_team': 'Everton', 'away_team': 'Coventry City', 'match_time': null,
        'anchors': [{'room_num': 'repo:match:aaaaaaaaaaaaaaaaaaaaaaaaaaaa'}],
      }]}), 200);
    }));
  });

  testWidgets('Soco All dates excludes old completed fixtures and labels rooms', (tester) async {
    final now = DateTime.now();
    final feed = [
      {
        'source_id': 'finished-long-ago',
        'league': 'MGL D1',
        'home_team': 'Central Stallions',
        'away_team': 'Deren FC',
        'match_time': now.subtract(const Duration(hours: 8)).toUtc().toIso8601String(),
        'anchors': [
          {'room_num': 'room-a'},
          {'room_num': 'room-b'},
        ],
      },
      {
        'source_id': 'current',
        'league': 'ACL Elite',
        'home_team': 'Pakhtakor',
        'away_team': 'Al Nassr',
        'match_time': now.add(const Duration(hours: 2)).toUtc().toIso8601String(),
        'anchors': [
          {'room_num': 'room-c'},
          {'room_num': 'room-d'},
        ],
      },
    ];
    await http.runWithClient(() async {
      await tester.pumpWidget(const MaterialApp(home: SourceBrowserPage(source: 'soco')));
      await tester.pumpAndSettle();
      expect(find.text('1 match'), findsOneWidget);
      expect(find.text('Central Stallions'), findsNothing);
      expect(find.text('Pakhtakor'), findsOneWidget);
      expect(find.textContaining('2 ROOMS'), findsOneWidget);
      expect(find.textContaining('2 SOURCES'), findsNothing);
      await tester.pumpWidget(const SizedBox.shrink());
    }, () => MockClient((request) async =>
      request.url.path.endsWith('/matches')
        ? http.Response(jsonEncode({'matches': feed}), 200)
        : http.Response('{}', 404)));
  });

  testWidgets('Soco removes a provider-deleted match after a successful refresh', (tester) async {
    final now = DateTime.now().toUtc();
    final fixture = {
      'source_id': 'provider-deletes-this',
      'league': 'ACL Elite',
      'home_team': 'Pakhtakor',
      'away_team': 'Al Nassr',
      'match_time': now.add(const Duration(hours: 2)).toIso8601String(),
      'anchors': <Map<String,dynamic>>[],
    };
    var current = <Map<String,dynamic>>[fixture];
    await http.runWithClient(() async {
      await tester.pumpWidget(const MaterialApp(home: SourceBrowserPage(source: 'soco')));
      await tester.pumpAndSettle();
      expect(find.text('Pakhtakor'), findsOneWidget);
      current = [];
      await tester.tap(find.byTooltip('Refresh matches'));
      await tester.pumpAndSettle();
      expect(find.text('Pakhtakor'), findsNothing);
      expect(find.text('No Soco matches'), findsOneWidget);
      await tester.pumpWidget(const SizedBox.shrink());
    }, () => MockClient((request) async =>
        request.url.path.endsWith('/matches')
          ? http.Response(jsonEncode({'ok':true,'matches':current}),200)
          : http.Response('{}',404)));
  });

  testWidgets('source categories are shown in one bottom nav only, never as top duplicate buttons',
      (tester) async {
    await http.runWithClient(() async {
      await tester.pumpWidget(
        const MaterialApp(home: SourceBrowserPage(source: 'yyzb')),
      );
      await tester.pumpAndSettle();
      expect(find.byType(PremiumBottomNav), findsOneWidget);
      for (final title in ['Soco', 'Fawa', 'ColaTV', 'Channels']) {
        expect(find.descendant(
          of: find.byType(AppBar), matching: find.text(title),
        ), findsNothing);
      }
      await tester.pumpWidget(const SizedBox.shrink());
    }, () => MockClient((request) async =>
        request.url.path.endsWith('/matches')
          ? http.Response(jsonEncode({'matches': _fixtures()}), 200)
          : http.Response('{}', 404)));
  });


  testWidgets('legacy YYZB rows show translated known teams and preserve unknown names', (
    tester,
  ) async {
    final now = DateTime.now();
    final kickoff = DateTime(now.year, now.month, now.day, 23, 59);
    final chineseRows = [
      {
        'source_id': 'fixture-42',
        'league': '德甲',
        'home_team': '帕德博恩',
        'away_team': '斯图加特',
        'match_time': kickoff.toUtc().toIso8601String(),
        'anchors': [
          {'room_num': 'room-7', 'nick_name': '老白聊球'},
        ],
      },
      {
        'source_id': 'fixture-43',
        'league': '未知联赛',
        'home_team': '未知球队',
        'away_team': '球队测试',
        'match_time': kickoff.toUtc().toIso8601String(),
        'anchors': [],
      },
    ];
    await http.runWithClient(
      () async {
        await tester.pumpWidget(
          const MaterialApp(home: SourceBrowserPage(source: 'yyzb')),
        );
        await tester.pumpAndSettle();
        expect(find.text('SC Paderborn 07'), findsOneWidget);
        expect(find.text('VfB Stuttgart'), findsOneWidget);
        // A team without a stream room never appears in the watchable-room
        // catalogue.
        expect(find.text('未知球队'), findsNothing);
        expect(find.text('球队测试'), findsNothing);
        expect(find.text('帕德博恩'), findsNothing);
        expect(find.text('未知联赛'), findsNothing);
        expect(tester.takeException(), isNull);
        await tester.enterText(
          find.byKey(const ValueKey('source-match-search')),
          'paderborn stuttgart',
        );
        await tester.pumpAndSettle();
        expect(find.text('1 match'), findsOneWidget);
        expect(find.text('SC Paderborn 07'), findsOneWidget);
        expect(find.text('未知球队'), findsNothing);
        await tester.pumpWidget(const SizedBox());
      },
      () => MockClient((request) async => request.url.path.endsWith('/matches')
          ? http.Response(jsonEncode({'matches': chineseRows}), 200,
              headers: {'content-type': 'application/json; charset=utf-8'})
          : http.Response('{}', 404)),
    );
  });

  testWidgets('phone filter controls remain usable with enlarged text', (
    tester,
  ) async {
    tester.view.devicePixelRatio = 1;
    tester.view.physicalSize = const Size(393, 852);
    addTearDown(tester.view.resetPhysicalSize);
    addTearDown(tester.view.resetDevicePixelRatio);
    final controller = TextEditingController();
    addTearDown(controller.dispose);
    await tester.pumpWidget(
      MaterialApp(
        builder: (context, child) => MediaQuery(
          data: MediaQuery.of(
            context,
          ).copyWith(textScaler: TextScaler.linear(1.5)),
          child: child!,
        ),
        home: Scaffold(
          body: SingleChildScrollView(
            child: SourceMatchFilters(
              controller: controller,
              todayOnly: true,
              leagues: const ['English Premier League', 'Bundesliga'],
              league: null,
              visibleCount: 2,
              onQueryChanged: (_) {},
              onTodayChanged: (_) {},
              onLeagueChanged: (_) {},
            ),
          ),
        ),
      ),
    );
    await tester.pumpAndSettle();
    expect(tester.takeException(), isNull);
    expect(find.text('Today'), findsOneWidget);
    expect(find.text('All dates'), findsOneWidget);
    expect(find.text('All leagues'), findsOneWidget);
    await tester.pumpWidget(const SizedBox());
  });

  testWidgets('landscape source search fits above the open keyboard', (
    tester,
  ) async {
    tester.view.devicePixelRatio = 1;
    tester.view.physicalSize = const Size(812, 375);
    addTearDown(tester.view.resetPhysicalSize);
    addTearDown(tester.view.resetDevicePixelRatio);
    addTearDown(tester.view.resetViewInsets);
    await http.runWithClient(
      () async {
        try {
          await tester.pumpWidget(
            const MaterialApp(home: SourceBrowserPage(source: 'yyzb')),
          );
          await tester.pumpAndSettle();
          expect(tester.takeException(), isNull);
          await tester.tap(find.byKey(const ValueKey('source-match-search')));
          tester.view.viewInsets = const FakeViewPadding(bottom: 216);
          await tester.pumpAndSettle();
          expect(tester.takeException(), isNull);
        } finally {
          await tester.pumpWidget(const SizedBox());
        }
      },
      () => MockClient(
        (request) async => request.url.path.endsWith('/matches')
            ? http.Response(jsonEncode({'matches': _fixtures()}), 200)
            : http.Response('{}', 404),
      ),
    );
  });

  testWidgets('YYZB shows only watchable rooms across local midnight', (
    tester,
  ) async {
    final requests = <Uri>[];
    await http.runWithClient(
      () async {
        await tester.pumpWidget(
          const MaterialApp(home: SourceBrowserPage(source: 'yyzb')),
        );
        await tester.pumpAndSettle();
        expect(find.text('2 matches'), findsOneWidget);
        expect(find.text('Arsenal'), findsOneWidget);
        expect(find.text('Dortmund'), findsNothing);
        expect(find.text('NOT READY'), findsNothing);
        expect(find.text('Chelsea'), findsOneWidget);
        expect(find.text('Today'), findsNothing);
        expect(find.text('All dates'), findsNothing);
        expect(find.byKey(const ValueKey('yyzb-streams-only')), findsNothing);
        expect(find.byKey(const ValueKey('yyzb-all-football')), findsNothing);
        expect(requests.every((uri) => uri.path.endsWith('/matches')), isTrue);

        await tester.enterText(
          find.byKey(const ValueKey('source-match-search')),
          'CHELSEA premier',
        );
        await tester.pumpAndSettle();
        expect(find.text('1 match'), findsOneWidget);
        expect(find.text('Chelsea'), findsOneWidget);
        expect(find.text('Arsenal'), findsNothing);

        await tester.tap(find.byTooltip('Clear search'));
        await tester.pumpAndSettle();
        expect(find.text('2 matches'), findsOneWidget);
        await tester.pumpWidget(const SizedBox());
      },
      () => MockClient((request) async {
        requests.add(request.url);
        return request.url.path.endsWith('/matches')
            ? http.Response(jsonEncode({'matches': _fixtures()}), 200)
            : http.Response('{}', 404);
      }),
    );
  });

  testWidgets('YYZB searchable league picker filters watchable rooms', (
    tester,
  ) async {
    await http.runWithClient(
      () async {
        await tester.pumpWidget(
          const MaterialApp(home: SourceBrowserPage(source: 'yyzb')),
        );
        await tester.pumpAndSettle();
        await tester.tap(find.text('All leagues'));
        await tester.pumpAndSettle();
        await tester.enterText(
          find.widgetWithText(TextField, 'Search leagues'),
          'premier',
        );
        await tester.pumpAndSettle();
        expect(find.widgetWithText(ListTile, 'Bundesliga'), findsNothing);
        await tester.tap(
          find.widgetWithText(ListTile, 'English Premier League'),
        );
        await tester.pumpAndSettle();
        expect(find.text('2 matches'), findsOneWidget);
        expect(find.text('Arsenal'), findsOneWidget);
        expect(find.text('Dortmund'), findsNothing);
        expect(find.text('Chelsea'), findsOneWidget);
        await tester.pumpWidget(const SizedBox());
      },
      () => MockClient(
        (request) async => request.url.path.endsWith('/matches')
            ? http.Response(jsonEncode({'matches': _fixtures()}), 200)
            : http.Response('{}', 404),
      ),
    );
  });
}
