import { withTelegramUpdateDedup } from './telegram_update_dedup.mjs';
import { createViewerFeatures } from './viewer_bot_features.mjs';
import { sendTelegramReleaseApk, ReleaseDeliveryError } from './telegram_apk_delivery.mjs';
// NCA Telegram bots: private webhook commands backed by safe Supabase metadata.
// NO stream URLs, key IDs, key data, DRM, service keys or session tokens in replies.
export const VIEWER_SITE = "https://nyeinchanaung75299-eng.github.io/football-stream-app/";
export const ADMIN_SITE = VIEWER_SITE + "admin/";
// Inline navigation complements the native Telegram /commands menu.
export const VIEWER_INLINE_MENU = {
  inline_keyboard: [
    [{ text: "⚽ Today", callback_data: "/today" }, { text: "🔴 Live", callback_data: "/live" }],
    [{ text: "📅 Schedule", callback_data: "/schedule" }, { text: "📺 Channels", callback_data: "/channels" }],
    [{ text: "🔔 My reminders", callback_data: "/reminders" }, { text: "📦 Viewer APK", callback_data: "/apk" }],
    [{ text: "🛠️ Build status", callback_data: "/build" }],
    [{ text: "Open Viewer", url: VIEWER_SITE }],
  ],
};

const reply = (body, status = 200) =>
  Response.json(body, { status, headers: { "Cache-Control": "no-store" } });
const text = (value, limit = 100) => String(value ?? "").replace(/[\u0000-\u001f\u007f]/g, " ").trim().slice(0, limit);
const dateInMyanmar = (iso) => {
  const date = new Date(iso);
  return Number.isNaN(date.valueOf()) ? "Time unavailable" :
    new Intl.DateTimeFormat("en-GB", {
      timeZone: "Asia/Yangon", day: "2-digit", month: "short",
      hour: "2-digit", minute: "2-digit", hour12: true,
    }).format(date) + " MMT";
};
const myanmarDay = (date) => new Date(date.getTime() + 390 * 60000).toISOString().slice(0, 10);

async function sameSecret(provided, expected) {
  if (!provided || !expected) return false;
  const encoder = new TextEncoder();
  const digests = await Promise.all([provided, expected].map(v => crypto.subtle.digest("SHA-256", encoder.encode(v))));
  const a = new Uint8Array(digests[0]), b = new Uint8Array(digests[1]);
  let diff = 0;
  for (let i = 0; i < a.length; i++) diff |= a[i] ^ b[i];
  return diff === 0;
}

export function createTelegramHandler({ mode, env, fetcher = fetch, clock = () => new Date() }) {
  if (mode !== "viewer" && mode !== "admin") throw new Error("Unknown bot mode");
  const prefix = mode === "viewer" ? "TG_VIEWER" : "TG_ADMIN";
  const features = createViewerFeatures({env, fetcher, clock, site:VIEWER_SITE});

  async function telegram(method, token, body) {
    const response = await fetcher("https://api.telegram.org/bot" + token + "/" + method, {
      method: "POST", headers: { "Content-Type": "application/json" },
      body: JSON.stringify(body),
      signal: AbortSignal.timeout(10000),
    });
    if (!response.ok) throw new Error("Telegram API unavailable");
    const data = await response.json();
    if (data.ok !== true) throw new Error("Telegram rejected message");
  }
  async function database(path, env) {
    const url = (env.SUPABASE_URL || "").replace(/\/+$/, "") + "/rest/v1/" + path;
    const response = await fetcher(url, {
      headers: {
        apikey: env.SUPABASE_SERVICE_ROLE_KEY,
        Authorization: "Bearer " + env.SUPABASE_SERVICE_ROLE_KEY,
        Accept: "application/json",
      },
      signal: AbortSignal.timeout(10000),
    });
    if (!response.ok) throw new Error("Database metadata unavailable");
    const rows = await response.json();
    if (!Array.isArray(rows)) throw new Error("Invalid database metadata");
    return rows;
  }
  async function matches(command, env, page=0) {
    const today = myanmarDay(clock()), now = clock().valueOf();
    const start = command === '/today' ? new Date(today+'T00:00:00+06:30').toISOString()
      : new Date(command === '/live' ? now-8*3600000 : now).toISOString();
    const end = command === '/today' ? new Date(new Date(start).valueOf()+86400000).toISOString()
      : new Date(now+7*86400000).toISOString();
    const data = await database("matches?select=id,league,home_team,away_team,kickoff_at,is_live" +
      "&is_active=eq.true&is_featured=eq.true&publish_state=eq.published&deleted_at=is.null" +
      '&is_finished=eq.false&and=(kickoff_at.gte.'+start+',kickoff_at.lt.'+end+')'+
      (command === '/live' ? '&is_live=eq.true' : '') +
      '&order=kickoff_at.asc&limit=10&offset='+(page*9), env);
    const items = data.filter(m => {
      const t = new Date(m.kickoff_at).valueOf();
      if (!Number.isFinite(t)) return false;
      if (command === "/live") return m.is_live === true;
      if (command === "/today") return myanmarDay(new Date(t)) === today;
      return t >= now && t <= now + 7 * 86400000;
    }).slice(0, 9);
    if (!items.length) return {text:command === "/live" ?
      "No verified live football matches right now." : "No published football matches for this selection."};
    const message = (command === "/live" ? "🔴 LIVE FOOTBALL" : command === "/today" ? "⚽ TODAY'S FOOTBALL" : "📅 UPCOMING FOOTBALL") +
      "\n" + items.map(m => text(m.home_team, 50) + " vs " + text(m.away_team, 50) +
        "\n" + text(m.league, 70) + " • " + dateInMyanmar(m.kickoff_at)).join("\n\n") +
      "\n\nWatch on NCA: " + VIEWER_SITE;
    const buttons=items.filter(m=>/^[a-f0-9-]{36}$/i.test(m.id||'')).map(m=>[
      {text:'Watch '+text(m.home_team,25),url:VIEWER_SITE+'?match='+m.id},
      {text:'🔔 Remind me',callback_data:'remind:'+m.id},
    ]);
    const nav=[];
    if(page>0)nav.push({text:'Previous',callback_data:'feed:'+command.slice(1)+':'+(page-1)});
    if(data.length>9)nav.push({text:'Next',callback_data:'feed:'+command.slice(1)+':'+(page+1)});
    if(nav.length)buttons.push(nav);
    return {text:message,keyboard:{inline_keyboard:buttons}};
  }
  // Private Admin navigation: only safe, non-credential channel metadata is sent.
  const PAGE_SIZE = 8;
  function makePage(rows, page, prefix, title) {
    const totalPages = Math.max(1, Math.ceil(rows.length / PAGE_SIZE));
    const requested = /^\d{1,4}$/.test(String(page)) ? Number(page) : 0;
    const current = Math.min(Math.max(requested, 0), totalPages - 1);
    const inline_keyboard = rows.slice(current * PAGE_SIZE, (current + 1) * PAGE_SIZE)
      .map(row => [{ text: text(row.name, 58), callback_data: "channel:" + row.id }]);
    const navigation = [];
    if (current > 0) navigation.push({ text: "⬅️ Previous", callback_data: prefix + ":" + (current - 1) });
    if (current + 1 < totalPages) navigation.push({ text: "Next ➡️", callback_data: prefix + ":" + (current + 1) });
    if (navigation.length) inline_keyboard.push(navigation);
    inline_keyboard.push([
      { text: "📁 Categories", callback_data: "/categories" },
      { text: "🏠 Main menu", callback_data: "/start" },
    ]);
    return {
      responseText: "📺 " + title + " (" + rows.length + ")\nPage " + (current + 1) +
        "/" + totalPages + "\nSelect a channel to view its details.",
      keyboard: { inline_keyboard },
    };
  }
  function groupCategories(rows) {
    const groups = new Map();
    for (const row of rows) {
      const category = String(row.category || "Other").trim() || "Other";
      groups.set(category, (groups.get(category) || 0) + 1);
    }
    return [...groups.entries()].sort((a, b) => a[0].localeCompare(b[0]));
  }
  function makeCategoryPage(rows, page) {
    const groups = groupCategories(rows);
    const totalPages = Math.max(1, Math.ceil(groups.length / PAGE_SIZE));
    const requested = /^\d{1,4}$/.test(String(page)) ? Number(page) : 0;
    const current = Math.min(Math.max(requested, 0), totalPages - 1);
    const inline_keyboard = groups.slice(current * PAGE_SIZE, (current + 1) * PAGE_SIZE)
      .map(([name, count], index) => [{
        text: text(name, 42) + " (" + count + ")",
        callback_data: "cat:" + (current * PAGE_SIZE + index) + ":0",
      }]);
    const navigation = [];
    if (current > 0) navigation.push({ text: "⬅️ Previous", callback_data: "cats:" + (current - 1) });
    if (current + 1 < totalPages) navigation.push({ text: "Next ➡️", callback_data: "cats:" + (current + 1) });
    if (navigation.length) inline_keyboard.push(navigation);
    inline_keyboard.push([{ text: "📺 All Channels", callback_data: "/channels" },
      { text: "🏠 Main menu", callback_data: "/start" }]);
    return {
      responseText: "📁 Categories (" + groups.length + ")\nPage " + (current + 1) + "/" +
        totalPages + "\nChoose a category.",
      keyboard: { inline_keyboard },
    };
  }
  function searchToken(query) {
    const bytes = new TextEncoder().encode(query);
    if (!bytes.length || bytes.length > 32) return null;
    return btoa(String.fromCharCode(...bytes)).replace(/\+/g, "-").replace(/\//g, "_").replace(/=+$/, "");
  }
  function decodeSearchToken(token) {
    if (!/^[A-Za-z0-9_-]{1,43}$/.test(token)) return null;
    try {
      const decoded = atob(token.replace(/-/g, "+").replace(/_/g, "/"));
      const bytes = Uint8Array.from(decoded, ch => ch.charCodeAt(0));
      return bytes.length > 32 ? null : new TextDecoder("utf-8", { fatal: true }).decode(bytes);
    } catch {
      return null;
    }
  }
  async function channelList(env, onlyBein) {
    const rows = await database("channels?select=id,name,category,epg_id,epg_source" +
      "&is_active=eq.true&order=name.asc&limit=250", env);
    return onlyBein ? rows.filter(r => /bein/i.test(r.name || "") || /bein/i.test(r.category || "")) : rows;
  }
  async function channelDetails(id, env) {
    if (!/^[0-9a-f-]{36}$/i.test(id)) return "Invalid channel selection.";
    const rows = await database("channels?select=id,name,category,epg_id,epg_source" +
      "&is_active=eq.true&id=eq." + encodeURIComponent(id) + "&limit=1", env);
    if (!rows.length) return "Channel not found.";
    // Never retrieve stream_url, key_id, key_data, or session credentials in Telegram.
    const lines = await database("channel_lines?select=label,stream_type,health_status,last_checked_at" +
      "&is_active=eq.true&channel_id=eq." + encodeURIComponent(id) + "&limit=20", env);
    const channel = rows[0];
    const statuses = lines.map((line, n) => "Line " + (n + 1) +
      " (" + text(line.label || "Server", 28) + "): " + text(line.stream_type || "auto", 16) +
      " • " + text(line.health_status || "unknown", 22));
    return "📺 " + text(channel.name, 110) + "\nCategory: " + text(channel.category, 65) +
      "\nEPG: " + text(channel.epg_id || "Not linked", 80) +
      "\nActive lines: " + lines.length + (statuses.length ? "\n" + statuses.join("\n") : "") +
      "\n\nManage protected playback details in the authenticated NCA Admin:\n" + ADMIN_SITE;
  }
  async function health(env) {
    const [channels, lines] = await Promise.all([
      database("channels?select=id&is_active=eq.true&limit=250", env),
      database("channel_lines?select=health_status&is_active=eq.true&limit=500", env),
    ]);
    const counts = { healthy: 0, slow: 0, failed: 0, unknown: 0 };
    for (const row of lines) {
      const status = String(row.health_status || "unknown").toLowerCase();
      counts[status in counts ? status : "unknown"]++;
    }
    return "📊 NCA CHANNEL HEALTH\nActive channels: " + channels.length +
      "\nActive lines: " + lines.length + "\n🟢 Healthy lines: " + counts.healthy +
      "\n🟡 Slow lines: " + counts.slow + "\n🔴 Failed lines: " + counts.failed +
      "\n⚪ Unknown lines: " + counts.unknown +
      "\n\nHealth indicates reachability, not guaranteed playback.";
  }
  async function builds() {
    const response = await fetcher("https://api.github.com/repos/nyeinchanaung75299-eng/football-stream-app/actions/runs?branch=main&per_page=20", {
      headers: { Accept: "application/vnd.github+json", "User-Agent": "NCA-Telegram-Admin" },
    });
    if (!response.ok) throw new Error("GitHub build status unavailable");
    const json = await response.json();
    const recent = (json.workflow_runs || []).filter(r =>
      ["Build and Deploy Web Viewer", "Build Android V9.8 APKs"].includes(r.name)).slice(0, 2);
    if (!recent.length) return "No recent tracked Web/APK runs.";
    return "🛠️ NCA BUILDS\n" + recent.map(r => text(r.name, 55) + ": " +
      text(r.conclusion || r.status, 25) + "\n" + text(r.html_url, 190)).join("\n\n");
  }
  async function handle(req) {
    if (req.method !== "POST") return reply({ error: "Method not allowed" }, 405);
    if (mode==='viewer' && req.headers.has('x-nca-viewer-pulse-key')) return features.pulse(req);
    const token = env[prefix + "_BOT_TOKEN"];
    const secret = env[prefix + "_WEBHOOK_SECRET"];
    if (!token || !secret || !env.SUPABASE_URL || !env.SUPABASE_SERVICE_ROLE_KEY) {
      return reply({ error: "Bot not configured" }, 503);
    }
    if (!await sameSecret(req.headers.get("X-Telegram-Bot-Api-Secret-Token"), secret)) {
      return reply({ error: "Invalid webhook" }, 401);
    }
    const update = await req.json().catch(() => null);
    if (!update || typeof update !== "object") return reply({ error: "Bad update" }, 400);
    const callback = update.callback_query;
    const message = callback?.message || update.message;
    const from = callback?.from || update.message?.from;
    const chat = message?.chat;
    if (!chat || !from || !Number.isSafeInteger(chat.id) || !Number.isSafeInteger(from.id)) return reply({ ok: true });
    const raw = String(callback ? callback.data || "" : message.text || "").trim();
    const cmd = raw.split(/\s+/)[0].split("@")[0].toLowerCase();
    // The pairing command returns only the requesting user's OWN ID.
    // All Admin data remains inaccessible until that ID is explicitly allowlisted.
    if (mode === "admin") {
      if (chat.type !== "private" || String(chat.id) !== String(from.id)) return reply({ ok: true });
      if (cmd === "/whoami") {
        await telegram("sendMessage", token, {
          chat_id: chat.id, text: "Your Telegram User ID: " + String(from.id) +
            "\nAdd this ID to the private Supabase secret TG_ADMIN_USER_IDS to enable Admin commands.",
        });
        return reply({ ok: true });
      }
      const allowed = new Set((env.TG_ADMIN_USER_IDS || "").split(",").map(s => s.trim()).filter(Boolean));
      if (!allowed.has(String(from.id))) return reply({ ok: true });
    }
    if (callback && callback.id) await telegram("answerCallbackQuery", token, { callback_query_id: callback.id });
    let responseText, keyboard, documentSent = false;
    try {
      if (mode === "viewer") {
        const featureRaw=raw.replace(/^\/start\s+report_/, 'report:');
        const feature = chat.type==='private' ? await features.handle(featureRaw,chat.id) : null;
        const feed=raw.match(/^feed:(today|live|schedule):(\d{1,4})$/);
        if(feature) {
          responseText=feature.text;keyboard=feature.keyboard;
        } else if (["/today", "/live", "/schedule"].includes(cmd) || feed) {
          const result=await matches(feed?'/'+feed[1]:cmd,env,feed?Number(feed[2]):0);
          responseText=result.text;keyboard=result.keyboard;
        } else if (cmd === "/channels") {
          const rows = await channelList(env, false);
          responseText = "📺 NCA active channels: " + rows.length +
            "\nView EPG and authorized playback in the NCA website:\n" + VIEWER_SITE;
        } else if (cmd === "/build") {
          responseText = await builds();
        } else if (cmd === "/apk" || cmd === "/download") {
          if (chat.type !== "private" || String(chat.id) !== String(from.id)) {
            responseText = "📦 Open a private chat with @NCAFootballViewer_bot and send /apk to receive the Viewer file.";
          } else {
            await sendTelegramReleaseApk({ kind: "viewer", chatId: chat.id, token, fetcher });
            documentSent = true;
          }
        } else {
          responseText = "⚽ NCA FOOTBALL VIEWER\nChoose a tool below, or use the Telegram /commands menu.\n" +
            "/today /live /schedule /channels /reminders /unsubscribe /apk /build\n" +
            "Choose Remind me on a match for an optional kickoff reminder. /menu opens these buttons again.";
          keyboard = VIEWER_INLINE_MENU;
        }
      } else if (cmd === "/health" || cmd === "/status") {
        responseText = await health(env);
      } else if (cmd === "/build") {
        responseText = await builds();
      } else if (cmd === "/channels" || /^all:\d{1,4}$/.test(raw)) {
        const rows = await channelList(env, false);
        ({ responseText, keyboard } = makePage(rows, cmd === "/channels" ? 0 : raw.split(":")[1],
          "all", "All Channels"));
      } else if (cmd === "/categories" || /^cats:\d{1,4}$/.test(raw)) {
        const rows = await channelList(env, false);
        ({ responseText, keyboard } = makeCategoryPage(rows, cmd === "/categories" ? 0 : raw.split(":")[1]));
      } else if (/^cat:\d{1,4}:\d{1,4}$/.test(raw)) {
        const [_, categoryIndex, page] = raw.split(":");
        const rows = await channelList(env, false);
        const categories = groupCategories(rows);
        const category = categories[Number(categoryIndex)]?.[0];
        if (!category) {
          responseText = "Category not found. Open /categories again.";
        } else {
          ({ responseText, keyboard } = makePage(
            rows.filter(row => (String(row.category || "Other").trim() || "Other") === category),
            page, "cat:" + categoryIndex, category));
        }
      } else if (cmd === "/bein" || /^bein:\d{1,4}$/.test(raw)) {
        const rows = await channelList(env, true);
        ({ responseText, keyboard } = makePage(rows, cmd === "/bein" ? 0 : raw.split(":")[1],
          "bein", "beIN Sports"));
      } else if (cmd === "/search" || /^search:[A-Za-z0-9_-]{1,43}:\d{1,4}$/.test(raw)) {
        let query, page = 0, token;
        if (cmd === "/search") {
          query = raw.replace(/^\/search(?:@\w+)?/i, "").trim();
          token = searchToken(query);
        } else {
          const parts = raw.split(":");
          token = parts[1];
          page = parts[2];
          query = decodeSearchToken(token);
        }
        if (!query) {
          responseText = "🔎 Search channels\nSend /search followed by a channel name.\nExample: /search sports";
        } else if (!token || !decodeSearchToken(token)) {
          responseText = "Search is too long. Use a shorter name (up to 32 UTF-8 bytes).";
        } else {
          const rows = (await channelList(env, false)).filter(row =>
            String(row.name || "").toLocaleLowerCase().includes(query.toLocaleLowerCase()) ||
            String(row.category || "").toLocaleLowerCase().includes(query.toLocaleLowerCase()));
          ({ responseText, keyboard } = makePage(rows, page, "search:" + token, 'Search: ' + text(query, 45)));
        }
      } else if (raw.startsWith("channel:")) {
        responseText = await channelDetails(raw.slice("channel:".length), env);
        keyboard = { inline_keyboard: [
          [{ text: "📺 All Channels", callback_data: "/channels" },
           { text: "📁 Categories", callback_data: "/categories" }],
          [{ text: "🏠 Main menu", callback_data: "/start" }],
        ] };
      } else {
        responseText = "🛡️ NCA Private Admin\nCommands: /channels /categories /search /bein /health /build /whoami.\n" +
          "Protected stream data and keys stay in the authenticated Admin website.";
        keyboard = { inline_keyboard: [
          [{ text: "📺 All Channels", callback_data: "/channels" }, { text: "📁 Categories", callback_data: "/categories" }],
          [{ text: "🔎 Search", callback_data: "/search" }, { text: "📺 beIN Sports", callback_data: "/bein" }],
          [{ text: "🟢 Channel Health", callback_data: "/health" }, { text: "🛠️ Builds", callback_data: "/build" }],
          [{ text: "Open Admin", url: ADMIN_SITE }],
        ] };
      }
    } catch (error) {
      responseText = error instanceof ReleaseDeliveryError
        ? "📦 APK delivery unavailable (" + error.code + "). The bot did not send an unverified file. Try /apk again later."
        : "NCA data is temporarily unavailable. Try again later.";
    }
    if (documentSent) return reply({ ok: true });
    await telegram("sendMessage", token, {
      chat_id: chat.id, text: responseText.slice(0, 3900),
      disable_web_page_preview: true,
      ...(keyboard ? { reply_markup: keyboard } : {}),
    });
    return reply({ ok: true });
  }
  return withTelegramUpdateDedup(handle, {mode, env, fetcher});
}
